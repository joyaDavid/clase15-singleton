
package com.mycompany.clasen15;
public class ClaseN15 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
